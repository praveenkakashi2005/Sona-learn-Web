export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: {
    name: string;
    avatar: string;
    bio: string;
  };
  thumbnail: string;
  duration: string;
  modules: {
    title: string;
    lessons: string[];
  }[];
  enrolledStudents: number;
  rating: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}