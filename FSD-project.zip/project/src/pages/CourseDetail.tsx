import React from 'react';
import { useParams } from 'react-router-dom';
import { Clock, Users, Star, ChevronDown } from 'lucide-react';
import { courses } from '../data/mockData';

export default function CourseDetail() {
  const { id } = useParams<{ id: string }>();
  const course = courses.find((c) => c.id === id);

  if (!course) {
    return <div>Course not found</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Course Header */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="relative h-96">
            <img
              src={course.thumbnail}
              alt={course.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center">
              <div className="max-w-3xl mx-auto px-8 text-white">
                <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
                <p className="text-xl mb-6">{course.description}</p>
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-5 w-5" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>{course.enrolledStudents} students</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Star className="h-5 w-5 text-yellow-400" />
                    <span>{course.rating}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Course Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-8 mb-8">
              <h2 className="text-2xl font-bold mb-6">Course Content</h2>
              <div className="space-y-4">
                {course.modules.map((module, index) => (
                  <div key={index} className="border rounded-lg">
                    <button className="w-full flex items-center justify-between p-4 text-left">
                      <span className="font-medium">{module.title}</span>
                      <ChevronDown className="h-5 w-5" />
                    </button>
                    <div className="px-4 pb-4">
                      <ul className="space-y-2">
                        {module.lessons.map((lesson, lessonIndex) => (
                          <li
                            key={lessonIndex}
                            className="flex items-center text-gray-600 hover:text-indigo-600 cursor-pointer"
                          >
                            <span className="ml-2">{lesson}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Instructor Info and CTA */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-8 mb-8">
              <h2 className="text-2xl font-bold mb-6">Instructor</h2>
              <div className="flex items-center space-x-4 mb-4">
                <img
                  src={course.instructor.avatar}
                  alt={course.instructor.name}
                  className="w-16 h-16 rounded-full"
                />
                <div>
                  <h3 className="text-lg font-medium">{course.instructor.name}</h3>
                  <p className="text-gray-600">Instructor</p>
                </div>
              </div>
              <p className="text-gray-600 mb-6">{course.instructor.bio}</p>
            </div>

            <div className="bg-white rounded-lg shadow-md p-8">
              <button className="w-full bg-indigo-600 text-white py-3 rounded-md hover:bg-indigo-700 transition-colors">
                Start Learning
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}