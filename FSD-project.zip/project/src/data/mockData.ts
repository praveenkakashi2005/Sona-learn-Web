export const courses = [
  {
    id: "1",
    title: "Advanced Web Development",
    description: "Master modern web development with React, Node.js, and cloud technologies. Build real-world projects and develop a strong portfolio.",
    instructor: {
      name: "Dr. Sarah Chen",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
      bio: "Full-stack developer with 10+ years of experience in building enterprise applications. PhD in Computer Science."
    },
    thumbnail: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800",
    duration: "12 weeks",
    modules: [
      {
        title: "Frontend Fundamentals",
        lessons: ["HTML5 & CSS3", "JavaScript ES6+", "React Basics"]
      },
      {
        title: "Backend Development",
        lessons: ["Node.js Fundamentals", "RESTful APIs", "Database Design"]
      }
    ],
    enrolledStudents: 1234,
    rating: 4.8
  },
  {
    id: "2",
    title: "Data Science Essentials",
    description: "Learn the fundamentals of data science, including statistical analysis, machine learning, and data visualization.",
    instructor: {
      name: "Prof. Michael Torres",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400",
      bio: "Data scientist with expertise in machine learning and AI. Published researcher in computational statistics."
    },
    thumbnail: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800",
    duration: "10 weeks",
    modules: [
      {
        title: "Statistics Fundamentals",
        lessons: ["Probability Theory", "Statistical Inference", "Hypothesis Testing"]
      },
      {
        title: "Machine Learning",
        lessons: ["Supervised Learning", "Unsupervised Learning", "Deep Learning"]
      }
    ],
    enrolledStudents: 956,
    rating: 4.7
  },
  {
    id: "3",
    title: "Mobile App Development",
    description: "Create stunning mobile applications for iOS and Android using React Native. Learn app deployment and monetization.",
    instructor: {
      name: "Lisa Johnson",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400",
      bio: "Mobile app developer and UX designer with over 8 years of experience in creating successful apps."
    },
    thumbnail: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800",
    duration: "8 weeks",
    modules: [
      {
        title: "React Native Basics",
        lessons: ["Setup & Architecture", "Components & Props", "State Management"]
      },
      {
        title: "Advanced Features",
        lessons: ["Native Modules", "App Performance", "Publishing"]
      }
    ],
    enrolledStudents: 789,
    rating: 4.9
  }
];