import React from 'react';
import { Star, Users, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Course } from '../types';

interface CourseCardProps {
  course: Course;
}

export default function CourseCard({ course }: CourseCardProps) {
  return (
    <div className="bg-slate-800 rounded-lg shadow-xl overflow-hidden transition-transform hover:scale-[1.02] duration-300 border border-slate-700">
      <img
        src={course.thumbnail}
        alt={course.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-semibold text-white mb-2">{course.title}</h3>
        <p className="text-slate-400 mb-4 line-clamp-2">{course.description}</p>
        
        <div className="flex items-center space-x-4 mb-4">
          <img
            src={course.instructor.avatar}
            alt={course.instructor.name}
            className="w-10 h-10 rounded-full"
          />
          <div>
            <p className="text-sm font-medium text-white">{course.instructor.name}</p>
            <p className="text-sm text-slate-400">Instructor</p>
          </div>
        </div>

        <div className="flex items-center justify-between text-sm text-slate-400 mb-4">
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="w-4 h-4" />
            <span>{course.enrolledStudents} students</span>
          </div>
          <div className="flex items-center space-x-1">
            <Star className="w-4 h-4 text-yellow-400" />
            <span>{course.rating}</span>
          </div>
        </div>

        <Link
          to={`/courses/${course.id}`}
          className="block w-full text-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          Enroll Now
        </Link>
      </div>
    </div>
  );
}